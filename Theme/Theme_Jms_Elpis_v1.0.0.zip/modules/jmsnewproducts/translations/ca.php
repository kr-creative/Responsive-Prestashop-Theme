<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_ea9c86b74387b4d2c2a4cab5ed539c78'] = 'Jms New products';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_d3ee346c7f6560faa13622b6fef26f96'] = 'Displays a block featuring your store\'s newest products.';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_1cd777247f2a6ed79534d4ace72d78ce'] = 'Please complete the \"products to display\" field.';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_73293a024e644165e9bf48f270af63a0'] = 'Invalid number';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Settings updated';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_26986c3388870d4148b1b5375368a83d'] = 'Products to display';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_3ea7689283770958661c27c37275b89c'] = 'Define the number of products to be displayed in this block.';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_85dd6b2059e1ff8fbefcc9cf6e240933'] = 'Number of days for which the product is considered \'new\'';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_24ff4e4d39bb7811f6bdf0c189462272'] = 'Always display this block';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_d68e7b860a7dba819fa1c75225c284b5'] = 'Show the block even if no new products are available.';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_1529636c2dd134b028a08f7b131115b5'] = 'New Products';
$_MODULE['<{jmsnewproducts}prestashop>jmsnewproducts_2d0f6b8300be19cf35e89e66f0677f95'] = 'Add to cart';
