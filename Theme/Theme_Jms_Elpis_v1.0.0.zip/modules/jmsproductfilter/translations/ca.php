<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_04393372336e644669336d27a39aabe2'] = 'Jms Product Filter';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_3601638c1581defc5c2d2f55925382a3'] = 'Show Featured Product list on categories, filter and sort magical layouts.';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_8dd2f915acf4ec98006d11c9a4b0945b'] = 'Settings updated successfully.';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_e06ba84b50810a88438ae0537405f65a'] = 'Display products\' prices';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_1d986024f548d57b1d743ec7ea9b09d9'] = 'Show the prices of the products displayed in the block.';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_2e3f860b55f906d39c2bda0ed31b11d6'] = 'Products Filter';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_22c6735b370cecf293e32dca6c678185'] = 'Best Seller';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_3dc2c436d9cf528ec362ea4f77eac85f'] = 'Lastest';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_21021ea0e52be8e9c599f4dff41e5be0'] = 'Feature';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categories';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_137920017d1c694d8c9414fd58341179'] = 'Number of products for each category';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_cf8156f1f57a8603cd6b3a28c9c2c61b'] = 'Featured Products';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_a87460e733ee76a9d70aa94e5e360c95'] = 'Block Description : Displays featured products by category in your homepage';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_f2cd171bd42220283b7a595c3ff2aaaf'] = 'Sale';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_03c2e7e41ffc181a4e84080b4710e81e'] = 'New';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_2d0f6b8300be19cf35e89e66f0677f95'] = 'Add to cart';
$_MODULE['<{jmsproductfilter}prestashop>jmsproductfilter_6a5373df703ab2827a4ba7facdfcf779'] = 'Add to Wishlist';
