<?php
/**
* 2007-2014 PrestaShop
*
* Show on sale product on home page
*
*  @author    Joommasters <joommasters@gmail.com>
*  @copyright 2007-2014 Joommasters
*  @license   license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*  @Website: http://www.joommasters.com
*/

if (!defined('_PS_VERSION_'))
	exit;

class OnsaleProducts extends Module
{
	protected static $cache_products;

	public function __construct()
	{
		$this->name = 'onsaleproducts';
		$this->tab = 'front_office_features';
		$this->version = '1.0';
		$this->author = 'Joommasters';
		$this->need_instance = 0;

		$this->bootstrap = true;
		parent::__construct();

		$this->displayName = $this->l('On Sale Products on the homepage');
		$this->description = $this->l('Displays on sale products in central column of your homepage.');
	}

	public function install()
	{
		$this->_clearCache('*');
		Configuration::updateValue('JMS_ONSALE_NBR', 8);

		if (!parent::install() || !$this->registerHook('header') || !$this->registerHook('addproduct') || !$this->registerHook('updateproduct') || !$this->registerHook('deleteproduct') || !$this->registerHook('categoryUpdate') || !$this->registerHook('displayHomeTab') || !$this->registerHook('displayHomeTabContent'))
			return false;
		return true;
	}

	public function uninstall()
	{
		$this->_clearCache('*');

		return parent::uninstall();
	}

	public function getContent()
	{
		$output = '';
		$errors = array();
		if (Tools::isSubmit('submitOnSale'))
		{
			$nbr = (int)Tools::getValue('JMS_ONSALE_NBR');
			if (!$nbr || $nbr <= 0 || !Validate::isInt($nbr))
				$errors[] = $this->l('An invalid number of products has been specified.');
			else
				Configuration::updateValue('JMS_ONSALE_NBR', (int)$nbr);
			if (isset($errors) && count($errors))
				$output .= $this->displayError(implode('<br />', $errors));
			else
				$output .= $this->displayConfirmation($this->l('Your settings have been updated.'));
		}

		return $output.$this->renderForm();
	}

	public function hookDisplayHeader($params)
	{
		$this->hookHeader($params);
	}

	public function hookHeader($params)
	{
		if (isset($this->context->controller->php_self) && $this->context->controller->php_self != 'index')
			return;
		$this->context->controller->addCSS(($this->_path).'views/css/style.css', 'all');
	}
	public function getProducts($nb = 8) 
	{		
		$id_lang = Context::getContext()->language->id;
		$sql = 'SELECT p.*, product_shop.*, pl.*,MAX(image_shop.`id_image`) id_image 
				FROM `'._DB_PREFIX_.'product` p
				'.Shop::addSqlAssociation('product', 'p').'
				LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (p.`id_product` = pl.`id_product` '.Shop::addSqlRestrictionOnLang('pl').')				
				LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_product` = p.`id_product`)'.Shop::addSqlAssociation('image', 'i', false, 'image_shop.cover=1').'
				LEFT JOIN `'._DB_PREFIX_.'image_lang` il ON (image_shop.`id_image` = il.`id_image` AND il.`id_lang` = '.(int)$id_lang.')
				WHERE pl.`id_lang` = '.(int)$id_lang.' AND p.`on_sale` = 1 AND p.`active` = 1 GROUP BY p.`id_product` LIMIT 0,'.$nb;	 		
		
		$result = Db::getInstance()->executeS($sql);
		return Product::getProductsProperties((int)Context::getContext()->language->id, $result);				
		
	}
	public function _cacheProducts()
	{
		if (!isset(OnsaleProducts::$cache_products))
		{
			
			$nb = (int)Configuration::get('JMS_ONSALE_NBR');
			OnsaleProducts::$cache_products = OnsaleProducts::getProducts($nb);
						
		}	
		
		if (OnsaleProducts::$cache_products === false || empty(OnsaleProducts::$cache_products))
			return false;
	}

	public function hookDisplayHome()
	{
		$nb = (int)Configuration::get('JMS_ONSALE_NBR');
		$products = OnsaleProducts::getProducts($nb);
		$this->smarty->assign(
			array(
				'products' => $products,
				'homeSize' => Image::getSize(ImageType::getFormatedName('home')),
			)
		);		

		return $this->display(__FILE__, 'onsaleproducts.tpl', $this->getCacheId());
	}

	public function hookDisplayHomeTabContent()
	{
		return $this->hookDisplayHome();
	}

	public function hookAddProduct()
	{
		$this->_clearCache('*');
	}

	public function hookUpdateProduct()
	{
		$this->_clearCache('*');
	}

	public function hookDeleteProduct()
	{
		$this->_clearCache('*');
	}

	public function hookCategoryUpdate()
	{
		$this->_clearCache('*');
	}

	public function renderForm()
	{
		$fields_form = array(
			'form' => array(
				'legend' => array(
					'title' => $this->l('Settings'),
					'icon' => 'icon-cogs'
				),
				'description' => $this->l(''),
				'input' => array(
					array(
						'type' => 'text',
						'label' => $this->l('Number of products to be displayed'),
						'name' => 'JMS_ONSALE_NBR',
						'class' => 'fixed-width-xs',
						'desc' => $this->l('Set the number of products that you would like to display on homepage (default: 8).'),
					),
				),
				'submit' => array(
					'title' => $this->l('Save'),
				)
			),
		);

		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->table = $this->table;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$this->fields_form = array();
		$helper->id = (int)Tools::getValue('id_carrier');
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submitOnSale';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'fields_value' => $this->getConfigFieldsValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id
		);

		return $helper->generateForm(array($fields_form));
	}

	public function getConfigFieldsValues()
	{
		return array(
			'JMS_ONSALE_NBR' => Tools::getValue('JMS_ONSALE_NBR', Configuration::get('JMS_ONSALE_NBR')),
		);
	}
}
