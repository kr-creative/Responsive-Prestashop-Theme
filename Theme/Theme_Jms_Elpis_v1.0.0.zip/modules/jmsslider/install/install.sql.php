<?php
/**
* 2007-2015 PrestaShop
*
* Slider Layer module for prestashop
*
*  @author    Joommasters <joommasters@gmail.com>
*  @copyright 2007-2015 Joommasters
*  @license   license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*  @Website: http://www.joommasters.com
*/

$query = "CREATE TABLE IF NOT EXISTS `_DB_PREFIX_jms_slides` (
  `id_slide` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `class_suffix` varchar(100) NOT NULL,
  `bg_type` int(10) NOT NULL DEFAULT '1',
  `bg_image` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `bg_color` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '#FFF',
  `slide_link` varchar(100) NOT NULL,
  `order` int(10) NOT NULL,
  `status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_slide`)
) ENGINE=_MYSQL_ENGINE_  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

INSERT INTO `_DB_PREFIX_jms_slides` (`id_slide`, `title`, `class_suffix`, `bg_type`, `bg_image`, `bg_color`, `slide_link`, `order`, `status`) VALUES
(15, 'Slide 123-1', '', 1, 'd076f9476a6c4131f1ab9bd8cbfdfba5.jpg', '', '', 0, 1),
(20, 'Slide 123-3', '', 1, '272891a3fcd679ae081394fb86e8c35b.jpg', '', '', 2, 1),
(22, 'Slide 123-2', '', 1, '8c4b9e8cdc3cb459fd4c929032c8b0b2.jpg', '', '', 1, 1),
(23, 'Slide 4-1', '', 1, '6b75ac42bdd7fb37cb5069057d57bcae.jpg', '', '', 3, 1),
(24, 'Slide 4-2', '', 1, '455f864f6f396bb528858dbc6ecb218f.jpg', '', '', 4, 1),
(25, 'Slide 4-3', '', 1, 'c06d5c56886b0129330a33b599b5687a.jpg', '', '', 5, 1),
(26, 'Slide 56-2', '', 1, '5ecf57046f74e8c9238e54c929312018.jpg', '', '', 7, 1),
(27, 'Slide 56-3', '', 1, '1c129b803a6319bcd6401b94d15a96da.jpg', '', '', 8, 1),
(31, 'Slide 56-1', '', 1, '8ba3ef161d3eb9a63f21850b7800652d.jpg', '', '', 6, 1),
(32, 'Slide 7-1', '', 1, '7292cb48ee3b4c1001f22cf43fd5840f.jpg', '', '', 9, 1),
(33, 'Slide 7-2', '', 1, '06a670f905d6a3a8553c7587b015e97e.jpg', '', '', 10, 1),
(34, 'Slide 7-3', '', 1, 'c10ed8b655ffb59865d451f875f69a8f.jpg', '', '', 11, 1);

CREATE TABLE IF NOT EXISTS `_DB_PREFIX_jms_slides_homes` (
  `id_slide` int(10) NOT NULL,
  `id_homes` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_slide`,`id_homes`)
) ENGINE=_MYSQL_ENGINE_ DEFAULT CHARSET=utf8;

INSERT INTO `_DB_PREFIX_jms_slides_homes` (`id_slide`, `id_homes`) VALUES
(15, '1,2,3'),
(20, '1,2,3'),
(22, '1,2,3'),
(23, '4'),
(24, '4'),
(25, '4'),
(26, '5,6'),
(27, '5,6'),
(31, '5,6'),
(32, '7'),
(33, '7'),
(34, '7');

CREATE TABLE IF NOT EXISTS `_DB_PREFIX_jms_slides_lang` (
  `id_slide` int(10) NOT NULL AUTO_INCREMENT,
  `id_lang` int(10) NOT NULL,
  PRIMARY KEY (`id_slide`,`id_lang`)
) ENGINE=_MYSQL_ENGINE_  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

INSERT INTO `_DB_PREFIX_jms_slides_lang` (`id_slide`, `id_lang`) VALUES
(15, 0),
(20, 0),
(22, 0),
(23, 0),
(24, 0),
(25, 0),
(26, 0),
(27, 0),
(31, 0),
(32, 0),
(33, 0),
(34, 0);

CREATE TABLE IF NOT EXISTS `_DB_PREFIX_jms_slides_layers` (
  `id_layer` int(10) NOT NULL AUTO_INCREMENT,
  `id_slide` int(10) NOT NULL,
  `data_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `data_class_suffix` varchar(50) NOT NULL,
  `data_fixed` int(10) NOT NULL DEFAULT '0',
  `data_delay` int(10) NOT NULL DEFAULT '1000',
  `data_time` int(10) NOT NULL DEFAULT '1000',
  `data_x` int(10) NOT NULL DEFAULT '0',
  `data_y` int(10) NOT NULL DEFAULT '0',
  `data_in` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'left',
  `data_out` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'right',
  `data_ease_in` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'linear',
  `data_ease_out` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'linear',
  `data_step` int(10) NOT NULL DEFAULT '0',
  `data_special` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'cycle',
  `data_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `data_image` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_html` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `data_video` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `data_video_controls` int(10) NOT NULL DEFAULT '1',
  `data_video_muted` int(10) NOT NULL DEFAULT '0',
  `data_video_autoplay` int(10) NOT NULL DEFAULT '1',
  `data_video_loop` int(10) NOT NULL DEFAULT '1',
  `data_video_bg` int(10) NOT NULL DEFAULT '0',
  `data_font_size` int(10) NOT NULL DEFAULT '14',
  `data_line_height` int(10) NOT NULL,
  `data_style` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT 'normal',
  `data_color` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '#FFFFFF',
  `data_width` int(10) NOT NULL,
  `data_height` int(10) NOT NULL,
  `data_order` int(10) NOT NULL,
  `data_status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_layer`,`id_slide`)
) ENGINE=_MYSQL_ENGINE_  DEFAULT CHARSET=utf8 AUTO_INCREMENT=90 ;

INSERT INTO `_DB_PREFIX_jms_slides_layers` (`id_layer`, `id_slide`, `data_title`, `data_class_suffix`, `data_fixed`, `data_delay`, `data_time`, `data_x`, `data_y`, `data_in`, `data_out`, `data_ease_in`, `data_ease_out`, `data_step`, `data_special`, `data_type`, `data_image`, `data_html`, `data_video`, `data_video_controls`, `data_video_muted`, `data_video_autoplay`, `data_video_loop`, `data_video_bg`, `data_font_size`, `data_line_height`, `data_style`, `data_color`, `data_width`, `data_height`, `data_order`, `data_status`) VALUES
(27, 15, 'Winter collection', 'rokkitt-36', 0, 1500, 2000, 759, 286, 'top', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Winter collection', '', 0, 0, 0, 0, 0, 55, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(28, 15, 'ELITE FASHION WEAR', 'rokkitt-52-up', 0, 2000, 2500, 572, 363, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', 'ELITE FASHION WEAR', '', 0, 0, 0, 0, 0, 78, 0, 'normal', '#fd7469', 200, 50, 0, 1),
(29, 15, 'View collection', 'button', 0, 2500, 3000, 878, 547, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', '<a href=\"#\" title=\"View collection\">View collection</a>', '', 0, 0, 0, 0, 0, 24, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(39, 20, 'FEMALE’S COLLECTION', 'rokkitt-52', 0, 1200, 1700, 830, 250, 'top', 'fade', 'linear', 'linear', 0, '', 'text', '', 'FEMALE’S COLLECTION', '', 0, 0, 0, 0, 0, 85, 0, 'normal', '#242424', 200, 50, 0, 1),
(40, 20, 'Limited Time Discount As Now $29.00', 'rokkitt-26', 0, 1700, 2200, 940, 420, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Limited Time Discount As Now $29.00', '', 0, 0, 0, 0, 0, 44, 0, 'normal', '#383838', 200, 50, 0, 1),
(41, 20, 'Shop now', 'btn-shopnow', 0, 2200, 2700, 1150, 560, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', '<a href=\"#\" title=\"shop now\">Shop now</a>', '', 0, 0, 0, 0, 0, 24, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(45, 22, 'Best design for men ', 'rokkitt-52', 0, 1500, 2000, 170, 240, 'right', 'fade', 'linear', 'linear', 0, '', 'text', '', 'BEST DESIGN FOR MEN', '', 0, 0, 0, 0, 0, 85, 0, 'normal', '#242424', 200, 50, 0, 1),
(46, 22, 'Up To 50% Off Sale Now!', 'rokkitt-26', 0, 2000, 2500, 400, 420, 'right', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Up To 50% Off Sale Now!', '', 0, 0, 0, 0, 0, 44, 0, 'normal', '#383838', 200, 50, 0, 1),
(47, 22, 'Shop now', 'btn-shopnow', 0, 2500, 3000, 479, 560, 'right', 'fade', 'linear', 'linear', 0, '', 'text', '', '<a href=\"#\" title=\"shop now\">Shop now</a>', '', 0, 0, 0, 0, 0, 24, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(48, 23, 'FEMALE’S COLLECTION', 'rokkitt-24', 0, 1500, 2000, 650, 335, 'fade', 'fade', 'linear', 'linear', 0, '', 'text', '', 'FEMALE’S COLLECTION', '', 0, 0, 0, 0, 0, 36, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(49, 23, 'Sale off', 'rokkitt-100', 0, 2000, 2500, 640, 340, 'fade', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Sale off', '', 0, 0, 0, 0, 0, 151, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(50, 23, 'Up to 49%', 'rokkitt-28', 0, 2500, 3000, 871, 550, 'fade', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Up to 49%', '', 0, 0, 0, 0, 0, 42, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(51, 24, 'Men''s collection', 'rokkitt-24', 0, 1500, 2000, 700, 335, 'top', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'Men''s collection', '', 0, 0, 0, 0, 0, 36, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(52, 24, 'Street style', 'rokkitt-100', 0, 2000, 2500, 490, 340, 'bottom', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'Street style', '', 0, 0, 0, 0, 0, 151, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(53, 24, 'Selling off', 'rokkitt-28', 0, 2500, 3000, 860, 550, 'bottom', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'Selling off', '', 0, 0, 0, 0, 0, 42, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(54, 25, 'ACCESSORIES', 'rokkitt-24', 0, 1200, 1700, 780, 335, 'right', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'ACCESSORIES', '', 0, 0, 0, 0, 0, 36, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(55, 25, 'VINTAGE DESIGN', 'rokkitt-100', 0, 1700, 2200, 390, 340, 'left', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'VINTAGE DESIGN', '', 0, 0, 0, 0, 0, 151, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(56, 25, 'Discount 30%', 'rokkitt-28', 0, 2200, 2700, 840, 550, 'right', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'Discount 30%', '', 0, 0, 0, 0, 0, 42, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(57, 26, 'Male''s collection', 'rokkitt-52', 0, 1200, 1700, 93, 250, 'right', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'MALE''S COLLECTION', '', 0, 0, 0, 0, 0, 95, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(58, 26, 'Limited Time Discount As Now $29.00', 'rokkitt-20', 0, 1700, 2200, 155, 409, 'right', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'Limited Time Discount As Now $29.00', '', 0, 0, 0, 0, 0, 50, 0, 'normal', '#67646e', 200, 50, 0, 1),
(59, 26, 'Shop now', 'btn-small', 0, 2200, 2700, 338, 542, 'bottom', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', '<a href=\"#\" title=\"shop now\">Shop now</a>', '', 0, 0, 0, 0, 0, 37, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(60, 27, 'Fashion lookbook 2016', 'rokkitt-20', 0, 1200, 1700, 1042, 304, 'left', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'Fashion lookbook 2016', '', 0, 0, 0, 0, 0, 50, 0, 'normal', '#67646e', 200, 50, 0, 1),
(61, 27, 'Female trending', 'rokkitt-52', 0, 1700, 2200, 822, 377, 'left', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', 'FEMALE TRENDING', '', 0, 0, 0, 0, 0, 95, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(62, 27, 'Shop now', 'btn-small', 0, 2200, 2700, 1095, 561, 'bottom', 'fade', 'easeInOutBack', 'linear', 0, '', 'text', '', '<a href=\"#\" title=\"shop now\">Shop now</a>', '', 0, 0, 0, 0, 0, 37, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(72, 31, 'Spring - Summer 2016', 'rokkitt-20-reg', 0, 1700, 2200, 789, 494, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Spring - Summer 2016', '', 0, 0, 0, 0, 0, 44, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(73, 31, 'MODEL COLLECTION FOR WOMEN', 'rokkitt-38', 0, 1200, 1700, 305, 308, 'top', 'fade', 'linear', 'linear', 0, '', 'text', '', 'MODEL COLLECTION FOR WOMEN', '', 0, 0, 0, 0, 0, 84, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(74, 31, 'Shop now', 'btn-shopnow-white', 0, 2200, 2700, 840, 615, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', '<a href=\"#\" title=\"shop now\">Shop now</a>', '', 0, 0, 0, 0, 0, 33, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(76, 32, 'Text 1', '', 0, 2200, 2700, 847, 391, 'top', 'fade', 'linear', 'linear', 0, '', 'image', 'text-4.png', '', '', 0, 0, 0, 0, 0, 14, 0, 'normal', '#FFFFFF', 172, 50, 0, 1),
(77, 32, 'BEST DESIGN FOR MEN', 'rokkitt-up', 0, 1200, 1700, 612, 448, 'right', 'fade', 'linear', 'linear', 0, '', 'text', '', 'BEST DESIGN FOR MEN', '', 0, 0, 0, 0, 0, 62, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(78, 32, 'Limited Time Discount As Now $29.00', 'rokkitt-26 ', 0, 1700, 2200, 740, 575, 'left', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Limited Time Discount As Now $29.00', '', 0, 0, 0, 0, 0, 26, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(79, 32, 'Shop now', 'btn-white', 0, 2700, 3200, 862, 650, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', '<a href=\"#\" title=\"shop now\">Shop now</a>', '', 0, 0, 0, 0, 0, 15, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(80, 33, 'Text 5', '', 0, 2700, 3200, 864, 418, 'top', 'fade', 'linear', 'linear', 0, '', 'image', 'text-5.png', '', '', 0, 0, 0, 0, 0, 14, 0, 'normal', '#FFFFFF', 222, 36, 0, 1),
(81, 33, 'Text 6', '', 0, 1200, 1700, 658, 487, 'top', 'fade', 'linear', 'linear', 0, '', 'image', 'text-6.png', '', '', 0, 0, 0, 0, 0, 14, 0, 'normal', '#FFFFFF', 674, 109, 0, 1),
(82, 33, 'Off Up To 49%', 'rokkitt-20', 0, 1700, 2200, 879, 559, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Off Up To 49%', '', 0, 0, 0, 0, 0, 36, 0, 'normal', '#fd7469', 200, 50, 0, 1),
(83, 33, 'Limited Time Discount', 'rokkitt-26-no', 0, 2200, 2700, 875, 622, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Limited Time Discount', '', 0, 0, 0, 0, 0, 24, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(84, 33, 'Shop now', 'btn-white', 0, 3200, 3600, 917, 706, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', '<a href=\"#\" title=\"shop now\">Shop now</a>', '', 0, 0, 0, 0, 0, 15, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(85, 34, 'Style ', 'rokkitt-26', 0, 1700, 2200, 905, 452, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Style &amp; Model', '', 0, 0, 0, 0, 0, 26, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(86, 34, 'VINTAGE FASHION ', 'rokkitt-38', 0, 1200, 1700, 542, 345, 'right', 'fade', 'linear', 'linear', 0, '', 'text', '', 'VINTAGE FASHION', '', 0, 0, 0, 0, 0, 62, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(87, 34, 'TRENDING!', 'rokkitt-38', 0, 1300, 1800, 1067, 345, 'left', 'fade', 'linear', 'linear', 0, '', 'text', '', 'TRENDING!', '', 0, 0, 0, 0, 0, 62, 0, 'normal', '#fd7469', 200, 50, 0, 1),
(88, 34, 'Fashion', 'rokkitt-letter', 0, 2200, 2700, 539, 519, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', 'Fashion is about dressing according to what’s your wanted', '', 0, 0, 0, 0, 0, 24, 0, 'normal', '#ffffff', 200, 50, 0, 1),
(89, 34, 'Shop now', 'btn-white', 0, 2700, 3200, 914, 593, 'bottom', 'fade', 'linear', 'linear', 0, '', 'text', '', '<a href=\"#\" title=\"shop now\">Shop now</a>', '', 0, 0, 0, 0, 0, 15, 0, 'normal', '#ffffff', 200, 50, 0, 1);

CREATE TABLE IF NOT EXISTS `_DB_PREFIX_jms_slides_shop` (
  `id_slide` int(10) NOT NULL AUTO_INCREMENT,
  `id_shop` int(10) NOT NULL,
  PRIMARY KEY (`id_slide`,`id_shop`)
) ENGINE=_MYSQL_ENGINE_  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

INSERT INTO `_DB_PREFIX_jms_slides_shop` (`id_slide`, `id_shop`) VALUES
(15, 1),
(20, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1);
";
?>