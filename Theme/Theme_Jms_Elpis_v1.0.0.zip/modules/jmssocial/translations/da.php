<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{jmssocial}prestashop>jmssocial_863f34ff4bfd4d67d6515feb9071bdc5'] = 'Jms Social networking block';
$_MODULE['<{jmssocial}prestashop>jmssocial_094d3ac865853e0be9ba42e80f0f7ee7'] = 'Allows you to add information about your brand\'s social networking accounts.';
$_MODULE['<{jmssocial}prestashop>jmssocial_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{jmssocial}prestashop>jmssocial_76f8961bb8f4bb2b95c07650f30a7e7b'] = 'Facebook URL';
$_MODULE['<{jmssocial}prestashop>jmssocial_c162369096f0fe5784f05052ceee6b47'] = 'Your Facebook fan page.';
$_MODULE['<{jmssocial}prestashop>jmssocial_bcca29e10968edaf6e0154d2339ad556'] = 'Twitter URL';
$_MODULE['<{jmssocial}prestashop>jmssocial_1912cacf8a06a4eaa878c7313593715a'] = 'Your official Twitter accounts.';
$_MODULE['<{jmssocial}prestashop>jmssocial_ed90192dee4746591f0d17112b7a1a60'] = 'LinkedIn URL';
$_MODULE['<{jmssocial}prestashop>jmssocial_a8cc10f27c7fac99eca56a8f59190cfb'] = 'Your Linkedin Page.';
$_MODULE['<{jmssocial}prestashop>jmssocial_ad7198d676478ac70c3243c1d3446331'] = 'YouTube URL';
$_MODULE['<{jmssocial}prestashop>jmssocial_5817a34292f074f9f596de6cb3607540'] = 'Your official YouTube account.';
$_MODULE['<{jmssocial}prestashop>jmssocial_85eac9d4572e285262a3e76130dcb4ea'] = 'Google Plus URL:';
$_MODULE['<{jmssocial}prestashop>jmssocial_be1d482ea5d68e157ad2ebe18612a4b1'] = 'You official Google Plus page.';
$_MODULE['<{jmssocial}prestashop>jmssocial_76abe3a162f22f63fae44d60fbe8f11b'] = 'Pinterest URL:';
$_MODULE['<{jmssocial}prestashop>jmssocial_e158a81859319b5e442bc490b0e81af3'] = 'Your official Pinterest account.';
$_MODULE['<{jmssocial}prestashop>jmssocial_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
