<?php
define('_JMS_THEME_SKINS_', 'color2,color3,color4,color5,color6,color7');
define('_JMS_PRODUCT_HOVERS_',"image_blur:Image Blur,image_swap:Image Swap");
define('_JMS_PRODUCT_BOXS_', '');
?>