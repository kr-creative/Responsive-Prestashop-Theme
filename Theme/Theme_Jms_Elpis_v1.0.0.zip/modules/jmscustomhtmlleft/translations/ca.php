<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{jmscustomhtmlleft}prestashop>jmscustomhtmlleft_73bd9ec003271480f677bbbb8c91c756'] = 'Jms Custom Html Left.';
$_MODULE['<{jmscustomhtmlleft}prestashop>jmscustomhtmlleft_8350f7d1530ec7b87598be6fba66c4d5'] = 'Enter html codes and show them in Left position of your theme.';
$_MODULE['<{jmscustomhtmlleft}prestashop>jmscustomhtmlleft_d52eaeff31af37a4a7e0550008aff5df'] = 'An error occurred while attempting to save.';
$_MODULE['<{jmscustomhtmlleft}prestashop>jmscustomhtmlleft_4f775b96d298f3555b5350e4a1d0d20d'] = 'custom Html Left block';
$_MODULE['<{jmscustomhtmlleft}prestashop>jmscustomhtmlleft_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Text';
$_MODULE['<{jmscustomhtmlleft}prestashop>jmscustomhtmlleft_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
