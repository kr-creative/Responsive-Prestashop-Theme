<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_52b3c0cb1eb4d9a45d0c1f55470780aa'] = 'Jms Top-sellers block';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_ed6476843a865d9daf92e409082b76e1'] = 'Adds a block displaying your store\'s top-selling products.';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Settings updated';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_24ff4e4d39bb7811f6bdf0c189462272'] = 'Always display this block';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_84b0c5fdef19ab8ef61cd809f9250d85'] = 'Show the block even if no best sellers are available.';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Top sellers';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_d3da97e2d9aee5c8fbe03156ad051c99'] = 'More';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_4351cfebe4b61d8aa5efa1d020710005'] = 'View';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_eae99cd6a931f3553123420b16383812'] = 'All best sellers';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_adc570b472f54d65d3b90b8cee8368a9'] = 'No best sellers';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_01f7ac959c1e6ebbb2e0ee706a7a5255'] = 'Best sellers';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_f2cd171bd42220283b7a595c3ff2aaaf'] = 'Sale';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_03c2e7e41ffc181a4e84080b4710e81e'] = 'New';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_2d0f6b8300be19cf35e89e66f0677f95'] = 'Add to cart';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_6a5373df703ab2827a4ba7facdfcf779'] = 'Add to Wishlist';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_7f5508c884f40e3378895c83d99cbbd3'] = 'Add to Compare';
$_MODULE['<{jmsbestsellers}prestashop>jmsbestsellers_70f23ff594252e51839210b6cc9641fc'] = 'Quick View';
