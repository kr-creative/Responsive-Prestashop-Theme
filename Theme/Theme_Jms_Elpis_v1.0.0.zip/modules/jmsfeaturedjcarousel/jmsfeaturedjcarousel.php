<?php
/**
* 2007-2015 PrestaShop
*
* Jms Featured Jcarousel
*
*  @author    Joommasters <joommasters@gmail.com>
*  @copyright 2007-2015 Joommasters
*  @license   license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*  @Website: http://www.joommasters.com
*/

if (!defined('_PS_VERSION_'))
	exit;

class JmsFeaturedJcarousel extends Module
{
	protected static $cache_products;

	public function __construct()
	{
		$this->name = 'jmsfeaturedjcarousel';
		$this->tab = 'front_office_features';
		$this->version = '1.6.3';
		$this->author = 'Joommasters';
		$this->need_instance = 0;

		$this->bootstrap = true;
		parent::__construct();

		$this->displayName = $this->l('Jms Featured Products Carousel');
		$this->description = $this->l('Displays featured products Carousel.');
	}

	public function install()
	{
		$this->_clearCache('*');
		Configuration::updateValue('JMS_FEATUREDCAROUSEL_COLS', 1);
		Configuration::updateValue('JMS_FEATUREDCAROUSEL_ROWS', 5);
		Configuration::updateValue('JMS_FEATUREDCAROUSEL_SCROLL', 0);
		Configuration::updateValue('JMS_FEATUREDCAROUSEL_TOTAL', 8);		
		Configuration::updateValue('JMS_FEATUREDCAROUSEL_RANDOMIZE', false);

		if (!parent::install() || !$this->registerHook('header') || !$this->registerHook('addproduct') || !$this->registerHook('updateproduct') || !$this->registerHook('deleteproduct') || !$this->registerHook('categoryUpdate'))
			return false;

		return true;
	}

	public function uninstall()
	{
		$this->_clearCache('*');
		return parent::uninstall();
	}

	public function getContent()
	{
		$output = '';
		$errors = array();		
		if (Tools::isSubmit('submitJMSFeaturedJcarousel'))
		{
			
			$fcp = Tools::getValue('JMS_FEATUREDCAROUSEL_COLS');
			if (!Validate::isInt($fcp) || $fcp <= 0)
			$errors[] = $this->l('The columns number of products is invalid. Please enter a positive number.');
			$frp = Tools::getValue('JMS_FEATUREDCAROUSEL_ROWS');
			if (!Validate::isInt($frp) || $frp <= 0)
			$errors[] = $this->l('The row number of products is invalid. Please enter a positive number.');
			$nbr = Tools::getValue('JMS_FEATUREDCAROUSEL_TOTAL');
			if (!Validate::isInt($nbr) || $nbr <= 0)
			$errors[] = $this->l('The number of products is invalid. Please enter a positive number.');

			$rand = Tools::getValue('JMS_FEATUREDCAROUSEL_RANDOMIZE');
			if (!Validate::isBool($rand))
				$errors[] = $this->l('Invalid value for the "randomize" flag.');
			if (isset($errors) && count($errors))
				$output = $this->displayError(implode('<br />', $errors));
			else
			{				
				Configuration::updateValue('JMS_FEATUREDCAROUSEL_COLS', (int)$fcp);
				Configuration::updateValue('JMS_FEATUREDCAROUSEL_ROWS', (int)$frp);
				Configuration::updateValue('JMS_FEATUREDCAROUSEL_SCROLL', Tools::getValue('JMS_FEATURED_SCROLL'));				
				Configuration::updateValue('JMS_FEATUREDCAROUSEL_TOTAL', (int)$nbr);				
				Configuration::updateValue('JMS_FEATUREDCAROUSEL_RANDOMIZE', (bool)$rand);
				Tools::clearCache(Context::getContext()->smarty, $this->getTemplatePath('jmsfeaturedjcarousel.tpl'));
				$output = $this->displayConfirmation($this->l('Your settings have been updated.'));
			}
		}

		return $output.$this->renderForm();
	}

	public function hookDisplayHeader($params)
	{
		$this->hookHeader($params);
	}

	public function hookHeader($params)
	{
		if (isset($this->context->controller->php_self) && $this->context->controller->php_self == 'index')
		$this->context->controller->addCSS(($this->_path).'views/css/jmsfeaturedjcarousel.css', 'all');
	}

	public function _cacheProducts()
	{
			$category = new Category((int)Configuration::get('HOME_FEATURED_CAT'), (int)Context::getContext()->language->id);
			$nb = (int)Configuration::get('JMS_FEATUREDCAROUSEL_TOTAL');
			if (Configuration::get('JMS_FEATUREDCAROUSEL_RANDOMIZE'))
				JmsFeaturedJcarousel::$cache_products = $category->getProducts((int)Context::getContext()->language->id, 1, ($nb ? $nb : 8), null, null, false, true, true, ($nb ? $nb : 8));
			else
				JmsFeaturedJcarousel::$cache_products = $category->getProducts((int)Context::getContext()->language->id, 1, ($nb ? $nb : 8), 'position');

		if (JmsFeaturedJcarousel::$cache_products === false || empty(JmsFeaturedJcarousel::$cache_products))
			return false;
	}
	function sliceProducts($products) 
	{
		$rows_number = (int)(Configuration::get('JMS_FEATUREDCAROUSEL_ROWS'));
		$cols_number = (int)(Configuration::get('JMS_FEATUREDCAROUSEL_COLS'));		
		$total_config = (int)(Configuration::get('JMS_FEATUREDCAROUSEL_TOTAL'));		
		if(count($products) > $total_config)
			$total = $total_config;
		else 
			$total = count($products);		
		if (Validate::isInt($total / $cols_number))
			$number_cols = $total / $cols_number;
		else
			$number_cols = $total / $cols_number + 1;
		if($rows_number > $number_cols)	
			$number_cols = $rows_number;		
		$result = array();		
		if($rows_number == 1) {			
			for ($i = 0; $i < count($products); $i++)
			{	
				$_index = floor($i / $cols_number);				
				$result[$_index][] = $products[$i];
			}			
		} else {
			for ($i = 0; $i < count($products); $i++)
			{	
				if($i % $number_cols == 0)
					$_index = 0;
				else 
					$_index = $i % $number_cols;			
				$result[$_index][] = $products[$i];
			}				
		}						
		return $result;
	}
	public function hookDisplayHome($params)
	{
			$this->_cacheProducts();
			$products = JmsFeaturedJcarousel::$cache_products;			
			$scoll = ((Configuration::get('JMS_FEATUREDCAROUSEL_SCROLL')) == 1 ? 'true' : 'false');
			$filter_products = $this->sliceProducts($products);			
			
			$this->smarty->assign(
				array(
					'columns_product' => Configuration::get('JMS_FEATUREDCAROUSEL_ROWS'),
					'filter_products' => $filter_products,
					'auto_play' => $scoll,					
					'add_prod_display' => Configuration::get('PS_ATTRIBUTE_CATEGORY_DISPLAY'),
					'homeSize' => Image::getSize(ImageType::getFormatedName('home')),
				)
			);

		return $this->display(__FILE__, 'jmsfeaturedjcarousel.tpl', $this->getCacheId());
	}

	public function hookAddProduct($params)
	{
		$this->_clearCache('*');
	}

	public function hookUpdateProduct($params)
	{
		$this->_clearCache('*');
	}

	public function hookDeleteProduct($params)
	{
		$this->_clearCache('*');
	}

	public function hookCategoryUpdate($params)
	{
		$this->_clearCache('*');
	}
	
	public function renderForm()
	{
		$fields_form = array(
			'form' => array(
				'legend' => array(
					'title' => $this->l('Settings'),
					'icon' => 'icon-cogs'
				),				
				'input' => array(
					array(
						'type' => 'text',
						'label' => $this->l('Number of Products Per Column'),
						'name' => 'JMS_FEATUREDCAROUSEL_COLS',
						'class' => 'fixed-width-xs',
					),
					array(
						'type' => 'text',
						'label' => $this->l('Number of Products Per Row'),
						'name' => 'JMS_FEATUREDCAROUSEL_ROWS',
						'class' => 'fixed-width-xs',
					),
					array(
						'type' => 'switch',
						'label' => $this->l('Auto Play'),
						'desc' => $this->l('ON/OFF auto play carousel in the block.'),
						'name' => 'JMS_FEATUREDCAROUSEL_SCROLL',
						'values' => array(
							array(
								'id' => 'active_on',
								'value' => 1,
								'label' => $this->l('Enabled')
							),
							array(
								'id' => 'active_off',
								'value' => 0,
								'label' => $this->l('Disabled')
							)
						),
					),
					array(
						'type' => 'text',
						'label' => $this->l('Number of products to be displayed'),
						'name' => 'JMS_FEATUREDCAROUSEL_TOTAL',
						'class' => 'fixed-width-xs',
						'desc' => $this->l('Set the number of products that you would like to display on homepage (default: 12).'),
					),					
					array(
						'type' => 'switch',
						'label' => $this->l('Randomly display featured products'),
						'name' => 'JMS_FEATUREDCAROUSEL_RANDOMIZE',
						'class' => 'fixed-width-xs',
						'desc' => $this->l('Enable if you wish the products to be displayed randomly (default: no).'),
						'values' => array(
							array(
								'id' => 'active_on',
								'value' => 1,
								'label' => $this->l('Yes')
							),
							array(
								'id' => 'active_off',
								'value' => 0,
								'label' => $this->l('No')
							)
						),
					),
				),
				'submit' => array(
					'title' => $this->l('Save'),
				)
			),
		);

		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->table = $this->table;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$this->fields_form = array();
		$helper->id = (int)Tools::getValue('id_carrier');
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submitJMSFeaturedJcarousel';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'fields_value' => $this->getConfigFieldsValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id
		);

		return $helper->generateForm(array($fields_form));
	}

	public function getConfigFieldsValues()
	{
		return array(
			'JMS_FEATUREDCAROUSEL_COLS' => Tools::getValue('JMS_FEATUREDCAROUSEL_COLS', (int)Configuration::get('JMS_FEATUREDCAROUSEL_COLS')),
			'JMS_FEATUREDCAROUSEL_ROWS' => Tools::getValue('JMS_FEATUREDCAROUSEL_ROWS', (int)Configuration::get('JMS_FEATUREDCAROUSEL_ROWS')),
			'JMS_FEATUREDCAROUSEL_SCROLL' => Tools::getValue('JMS_FEATUREDCAROUSEL_SCROLL', Configuration::get('JMS_FEATUREDCAROUSEL_SCROLL')),
			'JMS_FEATUREDCAROUSEL_TOTAL' => Tools::getValue('JMS_FEATUREDCAROUSEL_TOTAL', (int)Configuration::get('JMS_FEATUREDCAROUSEL_TOTAL')),			
			'JMS_FEATUREDCAROUSEL_RANDOMIZE' => Tools::getValue('JMS_FEATUREDCAROUSEL_RANDOMIZE', (bool)Configuration::get('JMS_FEATUREDCAROUSEL_RANDOMIZE')),
		);
	}
}
